# #letstalkaboutstress

Let’s talk about stress. Too much stress. 

We know this can be a topic.

So let’s get this conversation going. 

[Intro: two things you should know](#letstalkaboutstress%20b814c542d1744bbb83bf7e1d63e4bdda/Intro%20two%20things%20you%20should%20know%20e1bddd67170346d18fa7e5054114eab3.md)

[What is stress](#letstalkaboutstress%20b814c542d1744bbb83bf7e1d63e4bdda/What%20is%20stress%20269d3274c7e042fdb57c307c0f046f52.md)

[When is there too much stress?](#letstalkaboutstress%20b814c542d1744bbb83bf7e1d63e4bdda/When%20is%20there%20too%20much%20stress%203a100360163b4a6f9c75b54a670f28aa.md)

[What can I do](#letstalkaboutstress%20b814c542d1744bbb83bf7e1d63e4bdda/What%20can%20I%20do%2048a6dc9fc2c74a848a983d13108ffe45.md)

[What can Blendle do?](#letstalkaboutstress%20b814c542d1744bbb83bf7e1d63e4bdda/What%20can%20Blendle%20do%20f1ad1ffb4eeb4fa48ae3bf89aa4b200a.md)

[Good reads](#letstalkaboutstress%20b814c542d1744bbb83bf7e1d63e4bdda/Good%20reads%20a39698f6b87a420884e32eb0d126d33e.md)

Go to **#letstalkaboutstress** on slack to chat about this topic

# Work at Blendle

---

If you want to work at Blendle you can check our [job ads here](https://blendle.homerun.co/). If you want to be kept in the loop about Blendle, you can sign up for [our behind the scenes newsletter](https://blendle.homerun.co/yes-keep-me-posted/tr/apply?token=8092d4128c306003d97dd3821bad06f2).