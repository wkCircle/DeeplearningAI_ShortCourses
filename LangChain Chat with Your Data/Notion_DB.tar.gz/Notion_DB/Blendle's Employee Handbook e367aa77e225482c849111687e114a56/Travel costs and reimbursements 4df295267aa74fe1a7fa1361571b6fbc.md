# Travel costs and reimbursements

You will need to travel for Blendle (mostly from home to work and back). Blendle will cover your costs. Just look for the cheapest option (spend the money like it is your own).

When you travel by train: HR will get you an NS Business card, so all your home<>work travel is covered by Blendle. When travelling by car: you keep track of your kilometers and send an excel doc (or email) to finance@blendle and hr@blendle.com once a month to get your travel costs reimbursed. You'll get 0,19 per KM. HR can get you a parking card for P1.

If you need to reimburse other costs.

- Take a picture of your receipt.
- Send it to [finance@blendle.com](mailto:finance@blendle.com).
- The amount is added to your next salary (and payslip).

# Work at Blendle

---

If you want to work at Blendle you can check our [job ads here](https://blendle.homerun.co/). If you want to be kept in the loop about Blendle, you can sign up for [our behind the scenes newsletter](https://blendle.homerun.co/yes-keep-me-posted/tr/apply?token=8092d4128c306003d97dd3821bad06f2)